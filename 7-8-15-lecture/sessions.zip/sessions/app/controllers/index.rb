get '/' do
  @games = Game.all
  erb :index
end

get '/games/:id' do
  @game = Game.find(params[:id])
  erb :"games/show"
end

post '/favorites' do
  p params
  session[:favorite] = params[:id]
  redirect "/games/#{params[:id]}"
end
